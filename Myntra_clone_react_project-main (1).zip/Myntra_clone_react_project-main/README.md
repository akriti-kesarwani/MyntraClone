Figma Link- https://www.figma.com/design/CqPVgkBRaIuIf73l7MQILo/myntraclone?node-id=1-2&t=ONwnCgEDXMCYNzpH-1
# Myntra_clone_react_project
Demo day project on Myntra using react js 
 <span style="color:red">Myntra Clone of [Myntra.com](https://www.Myntra.com/) Website </span>

# <span style="color:red"> Welcome to Myntra</span>

<img src='https://images.indianexpress.com/2021/01/myntra.png?w=640' width="500" height='200' justify-content= 'center'>

myntra (Myntra Clone) is a one stop shop for all your fashion and lifestyle needs. Being India's largest e-commerce store for fashion and lifestyle products, a hassle free and enjoyable shopping experience to shoppers across the country with the widest range of brands and products on its portal.

# <span style="color:red"> Tech Stack Used: </span>

I have used React, Chakra, JS, Html, Css to made this project.

### Snapshots of Myntra project :- 

- ## <span style="color:blue"> Home Page: Header & Carousel </span>
<br />
<img src="https://github.com/faheemmuhammed1133/Myntra_clone_react_project/blob/main/carousal.png?raw=true"/>
- ## <span style="color:blue"> Men Page </span>
<br />
<img src="https://github.com/faheemmuhammed1133/Myntra_clone_react_project/blob/main/men.png?raw=true"/>
- ## <span style="color:blue"> Women Page </span>
<br />
<img src="https://github.com/faheemmuhammed1133/Myntra_clone_react_project/blob/main/women.png?raw=true"/>
- ## <span style="color:blue"> Kids Page </span>
<br />
<img src="https://github.com/faheemmuhammed1133/Myntra_clone_react_project/blob/main/kids.png?raw=true"/>
- ## <span style="color:blue"> Admin Page </span>
<br />
<img src="https://github.com/faheemmuhammed1133/Myntra_clone_react_project/blob/main/adminDashboard.png?raw=true"/>
- ## <span style="color:blue"> product view</span>
<br/>
<img src="https://github.com/faheemmuhammed1133/Myntra_clone_react_project/blob/main/product_view_new.png?raw=true"/>
<hr>

# Collaborators (Team members):-
- Piyush Singh
- Yashika Thakur
- Muhammed Faheem 
- Akriti Kesarwani

- ## <span style="color:green"> Thank You </span>
