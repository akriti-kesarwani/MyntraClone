export const GET_CART_LOADING = "get/cart/loading"
export const GET_CART_SUCCESS = "get/cart/success"
export const GET_CART_ERROR = "get/cart/error"
export const DELETE_CART_PRODUCT = "delete/cart/product"