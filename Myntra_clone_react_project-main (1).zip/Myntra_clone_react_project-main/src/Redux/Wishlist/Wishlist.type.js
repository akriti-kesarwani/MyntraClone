export const GET_WISHLIST_LOADING = "get/wishlist/loading"
export const GET_WISHLIST_SUCCESS = "get/wishlist/success"
export const GET_WISHLIST_ERROR = "get/wishlist/error"
export const DELETE_PRODUCT_SUCCESS = "delete/wishlist/success"
