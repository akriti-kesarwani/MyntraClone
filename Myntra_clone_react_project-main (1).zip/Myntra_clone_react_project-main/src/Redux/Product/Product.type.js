export const GET_PRODUCTS_LOADING = "products/get/loading"
export const GET_PRODUCTS_SUCCESS = "products/get/success"
export const GET_PRODUCTS_ERROR = "products/get/error"


export const GET_MAIN_DATA_SUCCESS = "products/get/success_main"
export const GET_FILTERED_PRODUCTS = "products/get/filteredProducts"
